package com.example.demo.service;

import com.example.demo.dbClasses.OptionDB;
import com.example.demo.repos.OptionRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OptionService {
    private final OptionRepos optionRepos;

    @Autowired
    public OptionService(OptionRepos optionRepos) {
        this.optionRepos = optionRepos;
    }

    public OptionDB save(OptionDB option) {
        return optionRepos.save(option);
    }

    public List<OptionDB> findAll() {
        return (List<OptionDB>) optionRepos.findAll();
    }
}