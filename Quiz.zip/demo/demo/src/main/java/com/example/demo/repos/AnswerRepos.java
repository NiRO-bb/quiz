package com.example.demo.repos;

import com.example.demo.dbClasses.AnswerDB;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AnswerRepos extends CrudRepository<AnswerDB, Integer>{
}
