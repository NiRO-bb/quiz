package com.example.demo;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Question {
    private int id;

    @NotBlank
    private String title;

    @NotBlank
    private String text;

    @NotNull
    @Size(min = 2)
    private String[] options;

    private Integer[] answer;

    public Question() {}

    public Question(String title, String text, String[] options, Integer answer[]) {
        this.title = title;
        this.text = text;
        this.options = options;
        this.answer = answer;
    }
    public Question(int id, String title, String text, String[] options, Integer answer[]) {
        this.id = id;
        this.title = title;
        this.text = text;
        this.options = options;
        this.answer = answer;
    }

    // id
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    // title
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    // text
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }

    // options
    public String[] getOptions() {
        return options;
    }
    public void setOptions(String[] options) {
        this.options = options;
    }

    // answer
    public Integer[] getAnswer() {
        return answer;
    }
    public void setAnswer(Integer[] answer) {
        this.answer = answer;
    }
}
