package com.example.demo.service;

import com.example.demo.dbClasses.QuestionDB;
import com.example.demo.repos.QuestionRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuestionService {
    private final QuestionRepos questionRepos;

    @Autowired
    public QuestionService(QuestionRepos questionRepos) {
        this.questionRepos = questionRepos;
    }

    public QuestionDB save(QuestionDB question) {
        return questionRepos.save(question);
    }

    public Optional<QuestionDB> findById(Integer id) {
        return questionRepos.findById(id);
    }

    public List<QuestionDB> findAll() {
        return (List<QuestionDB>) questionRepos.findAll();
    }
}