package com.example.demo;

public class Answer {
    private boolean success;
    private String feedback;

    public Answer(int[] answers, Integer[] rightAnswers) {
        boolean isFound = false, isRight = true;

        if (answers.length != rightAnswers.length) isRight = false;

        else {
            for (int answer : answers) {
                for (Integer rightAnswer : rightAnswers) {
                    if (rightAnswer.equals(answer-1)) {
                        isFound = true;
                        break;
                    }
                }

                if (!isFound) {
                    isRight = false;
                    break;
                }
            }
        }

        if (isRight) {
            success = true;
            feedback = "Congratulations, you're right!";
        }
        else {
            success = false;
            feedback = "Wrong answer! Please try again.";
        }
    }

    // success
    public boolean getSuccess() {
        return success;
    }
    public void setSuccess(boolean success) {
        this.success = success;
    }

    // feedback
    public String getFeedback() {
        return feedback;
    }
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
}
