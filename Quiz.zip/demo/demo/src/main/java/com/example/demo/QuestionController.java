package com.example.demo;

import com.example.demo.dbClasses.AnswerDB;
import com.example.demo.dbClasses.OptionDB;
import com.example.demo.dbClasses.QuestionDB;
import com.example.demo.service.AnswerService;
import com.example.demo.service.OptionService;
import com.example.demo.service.QuestionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

@RestController
public class QuestionController {

    // services
    @Autowired
    QuestionService questionService;
    @Autowired
    OptionService optionService;
    @Autowired
    AnswerService answerService;


    // questions
    private List<Question> questions = new ArrayList<>();
    private List<Question> noAnswers = new ArrayList<>();
    private List<String> optionsList = new ArrayList<>();

    // получить все вопросы
    @GetMapping("/api/quizzes")
    public List<Question> getQuestions() {
        // получение QuestionDB
        List<QuestionDB> questionsDB = questionService.findAll();

        // получение OptionDB
        List<OptionDB> optionsDB = optionService.findAll();

        // сборка вопросов по частям
        for (QuestionDB q : questionsDB) {
            // отбор OptionDB (вытаскиваем поле option по полю questionId)
            for (OptionDB optionDB : optionsDB) {
                if (optionDB.getQuestionId() == q.getId()) {
                    optionsList.add(optionDB.getOption()); // добавление option в массив
                }
            }

            // преобазование списка в массив
            String[] optionsArray = new String[optionsList.size()];
            for (int i = 0; i < optionsList.size(); i++)
                optionsArray[i] = optionsList.get(i);

            noAnswers.add(new Question(q.getId(), q.getTitle(), q.getText(), optionsArray, null));
            optionsList.clear(); // очистка списка
        }

        return noAnswers;
    }

    // получить вопрос по номеру
    @GetMapping("api/quizzes/{id}")
    public Question getQuestion(@PathVariable int id) {
        // получение QuestionDB
        Optional<QuestionDB> q = questionService.findById(id);

        // получение OptionDB
        List<OptionDB> optionsDB = optionService.findAll();

        try {
            // отбор OptionDB (вытаскиваем поле option по полю questionId)
            for (OptionDB optionDB : optionsDB) {
                if (optionDB.getQuestionId() == q.get().getId()) {
                    optionsList.add(optionDB.getOption()); // добавление option в массив
                }
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Отсутствует вопрос с указанным id - "+id);
        }

        // преобразование списка в массив
        String[] optionsArray = new String[optionsList.size()];
        for (int i = 0; i < optionsList.size(); i++)
            optionsArray[i] = optionsList.get(i);

        optionsList.clear(); // очистка списка

        return new Question(q.get().getId(), q.get().getTitle(), q.get().getText(), optionsArray, null);
    }

    // дать ответ
    @PostMapping("/api/quizzes/{id}/solve")
    public Answer questionAnswer(@PathVariable int id, @RequestParam int[] answer) {
        HashSet<Integer> ids = new HashSet<>();

        // получаем список ответов по questionId
        List<AnswerDB> answerDB = answerService.findAll();
        List<Integer> answerList = new ArrayList<>();
        for (AnswerDB a : answerDB) {
            ids.add(a.getQuestionId());
            if (a.getQuestionId() == id) {
                answerList.add(a.getAnswer());
            }
        }

        // преобразование списка в массив
        Integer[] answerArray = new Integer[answerList.size()];
        for (int i = 0; i < answerList.size(); i++)
            answerArray[i] = answerList.get(i);

        answerList.clear(); // очистка списка

        if (ids.contains(id)) return new Answer(answer, answerArray);
        else throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Отсутствует вопрос с указанным id - "+id);

    }

    // добавление нового вопроса
    @PostMapping("/api/quizzes")
    public Question addQuestion(@Valid @RequestBody Question question) {
        int id = 1;
        boolean isUnique = false;

        while (!isUnique) {
            isUnique = true;

            for (Question q : questions) {
                if (q.getId() == id) {
                    isUnique = false;
                    id++;
                    break;
                }
            }
        }

        question.setId(id);
        questions.add(question);

        Question forNoAnswers = new Question(question.getTitle(), question.getText(), question.getOptions(), null);
        forNoAnswers.setId(id);
        noAnswers.add(forNoAnswers);

        // добавление QuestionDB
        questionService.save(new QuestionDB(question.getId(), question.getTitle(), question.getText()));

        // добавление OptionDB
        for (String option : question.getOptions()) {
            optionService.save(new OptionDB(question.getId(), option));
        }

        // добавление AnswerDB
        for (Integer answer : question.getAnswer()) {
            answerService.save(new AnswerDB(question.getId(), answer));
        }

        return question;
    }
}