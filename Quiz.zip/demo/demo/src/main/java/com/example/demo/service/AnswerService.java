package com.example.demo.service;

import com.example.demo.dbClasses.AnswerDB;
import com.example.demo.repos.AnswerRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnswerService {
    public final AnswerRepos answerRepos;

    @Autowired
    public AnswerService (AnswerRepos answerRepos) {
        this.answerRepos = answerRepos;
    }

    public AnswerDB save(AnswerDB answer) {
        return answerRepos.save(answer);
    }

    public List<AnswerDB> findAll() {
        return (List<AnswerDB>) answerRepos.findAll();
    }
}
