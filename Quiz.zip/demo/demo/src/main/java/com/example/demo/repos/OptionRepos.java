package com.example.demo.repos;

import com.example.demo.dbClasses.OptionDB;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OptionRepos extends CrudRepository<OptionDB, Integer> {
}