package com.example.demo.dbClasses;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name="answers")
public class AnswerDB {
    @Id
    @GeneratedValue
    private int id;

    @Column
    private int questionId;

    @Column
    private int answer;

    public AnswerDB() {}

    public AnswerDB(int questionId, int answer) {
        this.questionId = questionId;
        this.answer = answer;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public int getAnswer() {
        return answer;
    }

    public void setAnswer(int answer) {
        this.answer = answer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AnswerDB answerDB = (AnswerDB) o;
        return id == answerDB.id && questionId == answerDB.questionId && answer == answerDB.answer;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, questionId, answer);
    }
}