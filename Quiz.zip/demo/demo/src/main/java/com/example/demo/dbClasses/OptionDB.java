package com.example.demo.dbClasses;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name="options")
public class OptionDB {
    @Id
    @GeneratedValue
    private int id;

    @Column
    private int questionId;

    @Column
    private String option;

    public OptionDB() {}

    public OptionDB(int questionId, String option) {
        this.questionId = questionId;
        this.option = option;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }

    public String getOption() {
        return option;
    }

    public void setOption(String option) {
        this.option = option;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OptionDB optionDB = (OptionDB) o;
        return id == optionDB.id && questionId == optionDB.questionId && Objects.equals(option, optionDB.option);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, questionId, option);
    }
}